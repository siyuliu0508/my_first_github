package com.example.tutron;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class tutor_registering extends AppCompatActivity {

    private EditText emailET, passwordET, firstNameET, lastNameET, languageET, descriptionET;
    private Spinner educationLevelSpinner;
    private ProgressBar progressBar;

    private FirebaseAuth mAuth;
    private FirebaseFirestore mDB;

    String role;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutor_registering);

        mAuth = FirebaseAuth.getInstance();
        mDB = FirebaseFirestore.getInstance();

        emailET = findViewById(R.id.email);
        passwordET = findViewById(R.id.password);
        firstNameET = findViewById(R.id.first_name);
        lastNameET = findViewById(R.id.last_name);
        educationLevelSpinner = findViewById(R.id.education_level);
        languageET = findViewById(R.id.native_language);
        descriptionET = findViewById(R.id.description);
        progressBar = findViewById(R.id.progress_bar);

        Button registerBtn = findViewById(R.id.register_button);
        registerBtn.setOnClickListener(v -> {
            registerUser();
            Intent intent = new Intent(getApplicationContext(), logged_activity.class);
            startActivity(intent);
            finish();
        });
    }

    private void registerUser() {
        role="Tutor";
        if (TextUtils.isEmpty(emailET.getText())) {
            Toast.makeText(tutor_registering.this, "Please enter email", Toast.LENGTH_SHORT).show();
            return;
        } else if (TextUtils.isEmpty(passwordET.getText())) {
            Toast.makeText(tutor_registering.this, "Please enter password", Toast.LENGTH_SHORT).show();
            return;
        } else if (TextUtils.isEmpty(firstNameET.getText())) {
            Toast.makeText(tutor_registering.this, "Please enter first name", Toast.LENGTH_SHORT).show();
            return;
        } else if (TextUtils.isEmpty(lastNameET.getText())) {
            Toast.makeText(tutor_registering.this, "Please enter last name", Toast.LENGTH_SHORT).show();
            return;
        } else if (TextUtils.isEmpty(descriptionET.getText())) {
            Toast.makeText(tutor_registering.this, "Please enter descriptive information", Toast.LENGTH_SHORT).show();
            return;
        }

        hideKeyboard(this);

        progressBar.setVisibility(View.VISIBLE);
        mAuth.createUserWithEmailAndPassword(emailET.getText().toString(), passwordET.getText().toString())
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        progressBar.setVisibility(View.GONE);
                        if (task.isSuccessful()) {
                            saveUserInfo();
                        } else {
                            Toast.makeText(tutor_registering.this, "Registration Failed.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void saveUserInfo() {
        FirebaseUser user = mAuth.getCurrentUser();
        Map<String, Object> userInfo = new HashMap<>();
        userInfo.put("email", emailET.getText().toString());
        userInfo.put("name", firstNameET.getText().toString() + lastNameET.getText().toString());
        userInfo.put("education", educationLevelSpinner.getSelectedItem().toString());
        userInfo.put("language", languageET.getText().toString());
        userInfo.put("description", descriptionET.getText().toString());
        userInfo.put("Role", role);

        progressBar.setVisibility(View.VISIBLE);
        mDB.collection("users").document(user.getUid()).set(userInfo).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(tutor_registering.this, "Registration Successful.", Toast.LENGTH_SHORT).show();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        finish();
                    }
                }, 2000);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(tutor_registering.this, "Error occurred while storing user info.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        View view = activity.getCurrentFocus();
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
}