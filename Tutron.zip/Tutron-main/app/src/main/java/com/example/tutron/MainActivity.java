package com.example.tutron;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    EditText textEmail,textPassword;
    private Button logBtn, regBtn;

    FirebaseAuth mAuth;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textEmail=findViewById(R.id.email);
        textPassword=findViewById(R.id.password);
        mAuth= FirebaseAuth.getInstance();

        regBtn= findViewById(R.id.registerButton);
        logBtn= findViewById(R.id.loginButton);

        regBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Application Context and Activity
                Intent intent = new Intent(getApplicationContext(), RegisteringType.class);
                startActivity(intent);
                finish();

            }
        });

        logBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email= textEmail.getText().toString();
                String password= textPassword.getText().toString();
                if (TextUtils.isEmpty(email)){Toast.makeText(MainActivity.this, "Enter your email address", Toast.LENGTH_SHORT).show(); return;}
                if (TextUtils.isEmpty(password)){Toast.makeText(MainActivity.this, "Enter your password", Toast.LENGTH_SHORT).show(); return;}

                mAuth.signInWithEmailAndPassword(textEmail.getText().toString(), textPassword.getText().toString())
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(MainActivity.this, "Login successful.", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(getApplicationContext(),logged_activity.class);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    Toast.makeText(MainActivity.this, "Authentication failed.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });

    }


}