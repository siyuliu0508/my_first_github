package com.example.tutron;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class RegisteringType extends AppCompatActivity {

    private Button stButton;
    private Button ttButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registering_type);

        stButton = findViewById(R.id.studentType);
        ttButton = findViewById(R.id.tutorType);

        stButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Application Context and Activity
                Intent intent = new Intent(getApplicationContext(), studentregistering.class);
                startActivity(intent);
                finish();
            }
        });


        ttButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Application Context and Activity
                Intent intent = new Intent(getApplicationContext(), tutor_registering.class);
                startActivity(intent);
                finish();
            }
        });
    }
}