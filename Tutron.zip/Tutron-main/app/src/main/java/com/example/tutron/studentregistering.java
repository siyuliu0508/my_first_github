package com.example.tutron;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class studentregistering extends AppCompatActivity {

    EditText textNameF,textNameL,textEmail,textPassword,textAddress,textCardCredit;
    Button regGBtn;

    String role;

    FirebaseAuth mAuth;

    FirebaseFirestore db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studentregistering);
        textNameF=findViewById(R.id.firstNameEditText);
        textNameL=findViewById(R.id.lastNameEditText);
        textEmail=findViewById(R.id.emailEditText);
        textPassword=findViewById(R.id.passwordEditText);
        textAddress=findViewById(R.id.addressEditText);
        textCardCredit=findViewById(R.id.creditCardEditText);
        regGBtn=findViewById(R.id.registeringButton);
        mAuth= FirebaseAuth.getInstance();
        db= FirebaseFirestore.getInstance();

        regGBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameF,nameL,email,password,address,cardCredit;
                nameF= textNameF.getText().toString();
                nameL= textNameL.getText().toString();
                email= textEmail.getText().toString();
                password= textPassword.getText().toString();
                address= textAddress.getText().toString();
                cardCredit= textCardCredit.getText().toString();
                role="student";

                if (TextUtils.isEmpty(nameF)){Toast.makeText(studentregistering.this, "Enter your first Name", Toast.LENGTH_SHORT).show(); return;}
                if (TextUtils.isEmpty(nameL)){Toast.makeText(studentregistering.this, "Enter your Last Name", Toast.LENGTH_SHORT).show(); return;}
                if (TextUtils.isEmpty(email)){Toast.makeText(studentregistering.this, "Enter your email address ", Toast.LENGTH_SHORT).show(); return;}
                if (TextUtils.isEmpty(password)){Toast.makeText(studentregistering.this, "Enter a Password", Toast.LENGTH_SHORT).show(); return;}
                if (TextUtils.isEmpty(address)){Toast.makeText(studentregistering.this, "Enter your address", Toast.LENGTH_SHORT).show(); return;}
                if (TextUtils.isEmpty(cardCredit)){Toast.makeText(studentregistering.this, "Enter your Credit Card", Toast.LENGTH_SHORT).show(); return;}




                mAuth.createUserWithEmailAndPassword(textEmail.getText().toString(), textPassword.getText().toString())
                        .addOnCompleteListener( new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    saveStudentInfo();
                                    //Application Context and Activity
                                    Intent intent = new Intent(getApplicationContext(), logged_activity.class);
                                    startActivity(intent);
                                    finish();

                                } else {
                                    // If sign in fails, display a message to the user.
                                    Toast.makeText(studentregistering.this, "Authentication failed.",
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

            }
        });

    }

    private void saveStudentInfo(){
        FirebaseUser user = mAuth.getCurrentUser();
        Map<String, Object> userInfo = new HashMap<>();
        userInfo.put("First name", textNameF.getText().toString());
        userInfo.put("Last name", textNameL.getText().toString());
        userInfo.put("email", textEmail.getText().toString());
        userInfo.put("address", textAddress.getText().toString());
        userInfo.put("Credit card", textCardCredit.getText().toString());
        userInfo.put("Role", role);

        assert user != null;
        db.collection("users").document(user.getUid()).set(userInfo).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(studentregistering.this, "Registration Successful.", Toast.LENGTH_SHORT).show();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        finish();
                    }
                }, 2000);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(studentregistering.this, "Error occurred while storing user info.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}