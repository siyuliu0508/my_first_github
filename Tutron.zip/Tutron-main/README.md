# Tutron
For login as an Admin : email: admin@uottawa.ca, password: adminn
